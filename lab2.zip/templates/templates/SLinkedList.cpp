#include <iostream>
#include "SLinkedList.h"
#include <string>

using namespace std;

int main() {

	//// Part 1: Demonstrate the very basic prinicpals of a linked list.

	//// Create a list node (there is no list object).
	//std::unique_ptr<SListNode<int>> p1 = std::make_unique<SListNode<int>>(3);
	//// Create a second list node, and link the first node to the second.
	//p1->setNext(std::make_unique<SListNode<int>>(4));
	//// Loop through each node in the list.
	//for (SListNode<int> *pCurrent = p1.get(); pCurrent != nullptr; pCurrent = pCurrent->next().get())
	//{
	//	cout << (*pCurrent).element() << endl;
	//}
	//// Q: What happens if the next line is uncommented?
	//p1 = std::move(p1->next());

	// Part 2: Create a linked list using a list object.

	SLinkedList<int, SListIterator<int>> list;	
	list.insertLast(20);
	list.insertLast(10);
	list.insertLast(5);
	list.insertLast(20);

	//list.remove(20);
	

	///////////////////////////////////
	SLinkedList<int, SListIterator<int>> myList;
	myList.insertLast(22);
	myList.insertLast(12);
	myList.insertLast(7);
	myList.insertLast(22);
	std::cout << "////////////////////////////////" << std::endl;

	for (int i = 0; i < 4; i++) {
		auto pointer = myList.begin();
		for (int j = 0; j < i; j++) {
			pointer++;
		}
		std::cout << std::to_string(pointer.get()) << std::endl;
	}

	std::cout << "////////////////////////////////" << std::endl;
	list.splice(list.begin(), myList);

	for each(int element in myList) {
		std::cout << std::to_string(element) << std::endl;
	}

	std::cout << "////////////////////////////////" << std::endl;

	//////////////////////////////////

	//////////////////////////////////
	std::list<int> randList;
	std::list<int> dest;
	auto firstIter = randList.back();
	for (int i = 0; i < 20; i++) {
		auto randInt = std::rand() % 10;
		randList.push_back(randInt);

		if (randList.back() == 2) {
			firstIter = randList.back();
		}
	}
	//randList.splice(randList.begin(), dest, randList.end());


	SListIterator<int> start = list.begin();
	
	std::cout << "First element: " << *start << endl;

	std::cout << list.size() << endl;
	
	system("PAUSE");
}
